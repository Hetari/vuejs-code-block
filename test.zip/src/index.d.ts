declare module 'index.d.ts' {
  import { DefineComponent } from 'vue';
  const VuejsCodeBlock: DefineComponent<{}, {}, any>;
  export default VuejsCodeBlock;
}
